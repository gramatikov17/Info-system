package com.example.InfoSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoSystemApplication.class, args);
	}

}
