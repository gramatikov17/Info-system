package com.example.InfoSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
